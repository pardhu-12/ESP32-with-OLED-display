#include<Wire.h>
#include <WiFi.h>
#include<Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

const char *ssid = "Wokwi-GUEST";
const char *password = "";


#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

void setup() {
  Serial.begin(115200);
  WiFi.begin(ssid,password);

  pinMode(19, OUTPUT);
  pinMode(34, INPUT);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("OLED not found!");
    while (true);
  }

  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  
  display.println("Hello ESP32!");
  display.display(); 
  
  display.print("connecting");
  display.display(); 

  while(WiFi.status() !=  WL_CONNECTED){
    delay(50);
    display.print(".");
    display.display(); 
  }

  
   display.clearDisplay();
   display.setCursor(0, 0);
   display.print("connected !");

  display.display(); 
}

void loop() {
  delay(2000);
  display.clearDisplay();
  
  int PIR_value = digitalRead(34);
  int LDR_value = analogRead(35);

  display.setCursor(0, 0);
  display.print("PIR value : ");
  display.println(PIR_value);

  display.print("LDR value : ");
  display.println(LDR_value);

  display.display();
  delay(1000);
  if(LDR_value < 1500 && PIR_value == 0){
    digitalWrite(19, HIGH);
    display.print("lED is ON");
    
  } else{
    digitalWrite(19, LOW);
    display.print("lED is OFF");
    
  }

  display.display();
  display.clearDisplay();


   delay(5000);
   display.setCursor(0, 0);
  if(LDR_value > 1500 && PIR_value == 0){
    digitalWrite(19, HIGH);
    display.print("lED is ON");
  } else{
    digitalWrite(19, LOW);
    display.print("lED is OFF");
  }

  display.display();
}
